DIRECTORY
	iRODS/server/drivers	- file system driver functions

DESCRIPTION
	This directory contains driver functions used to interface
	iRODS to various types of file systems.
