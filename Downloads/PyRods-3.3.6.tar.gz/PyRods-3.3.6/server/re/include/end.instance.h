/* For copyright information please refer to files in the COPYRIGHT directory
 */

#undef MK_TRANSIENT_PTR

#undef MK_TRANSIENT_VAL

#undef MK_VAL

#undef MK_PTR

#undef MK_PTR_TVAR

#undef MK_PTR_TAPP

#undef MK_ARRAY

#undef MK_ARRAY_IN_STRUCT

#undef MK_VAR_ARRAY

#undef MK_VAR_ARRAY_IN_STRUCT

#undef MK_PTR_ARRAY

#undef MK_PTR_ARRAY_IN_STRUCT

#undef MK_PTR_VAR_ARRAY

#undef MK_PTR_VAR_ARRAY_IN_STRUCT

#undef MK_PTR_TAPP_ARRAY

#undef MK_PTR_TAPP_ARRAY_IN_STRUCT

#undef PARAM

#undef RE_STRUCT_BEGIN

#undef RE_STRUCT_GENERIC_BEGIN

#undef RE_STRUCT_END

#undef RE_STRUCT_GENERIC_END

#ifdef RE_STRUCT_FUNC_PROTO
#undef RE_STRUCT_FUNC_PROTO
#endif

#ifdef RE_STRUCT_GENERIC_FUNC_PROTO
#undef RE_STRUCT_GENERIC_FUNC_PROTO
#endif

#ifdef RE_STRUCT_FUNC
#undef RE_STRUCT_FUNC
#endif

#ifdef RE_STRUCT_FUNC_TYPE
#undef RE_STRUCT_FUNC_TYPE
#endif

#ifdef TRAVERSE_BEGIN
#undef TRAVERSE_BEGIN
#endif

#ifdef TRAVERSE_END
#undef TRAVERSE_END
#endif

#ifdef TRAVERSE_PTR
#undef TRAVERSE_PTR
#endif

#ifdef TRAVERSE_PTR_TAPP
#undef TRAVERSE_PTR_TAPP
#endif

#ifdef TRAVERSE_ARRAY_BEGIN
#undef TRAVERSE_ARRAY_BEGIN
#endif

#ifdef TRAVERSE_ARRAY_END
#undef TRAVERSE_ARRAY_END
#endif

/*#ifdef KEY_SIZE
#undef KEY_SIZE
#endif*/

/*#ifdef COPY_PTR_ARRAY_COPIER
#undef COPY_PTR_ARRAY_COPIER
#endif
*/
#ifdef GET_VAR_ARRAY_LEN
#undef GET_VAR_ARRAY_LEN
#endif
