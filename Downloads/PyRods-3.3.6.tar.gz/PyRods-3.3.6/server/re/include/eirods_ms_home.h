
#ifndef __EIRODS_MS_HOME_H__
#define __EIRODS_MS_HOME_H__

#include <string>

namespace eirods {

	const std::string EIRODS_MS_HOME( "EIRODSMSVCPATH" );

}; // namespace eirods

#endif // __EIRODS_MS_HOME_H__
